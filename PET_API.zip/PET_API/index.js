﻿const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json());

const dataFile = path.join(__dirname, 'data', 'pets.json');
let pets = require(dataFile);

// GET all pets
app.get('/pets', (req, res) => res.json(pets));

// GET random pet
app.get('/pets/random', (req, res) => {
  const randomPet = pets[Math.floor(Math.random() * pets.length)];
  res.json(randomPet);
});

// GET pet by ID
app.get('/pets/:id', (req, res) => {
  const pet = pets.find(p => p.id == req.params.id);
  pet ? res.json(pet) : res.status(404).send('Pet not found');
});

// POST new pet
app.post('/pets', (req, res) => {
  const { pet_name, species, age } = req.body;
  if (!pet_name || !species || age === undefined)
    return res.status(400).send('Missing pet_name, species, or age');

  const newPet = {
    id: pets.length ? pets[pets.length - 1].id + 1 : 1,
    pet_name,
    species,
    age
  };

  pets.push(newPet);
  fs.writeFileSync(dataFile, JSON.stringify(pets, null, 2));
  res.status(201).json(newPet);
});

// DELETE pet
app.delete('/pets/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = pets.findIndex(p => p.id === id);
  if (index === -1) return res.status(404).json({ error: 'Pet not found' });

  const deleted = pets.splice(index, 1)[0];
  fs.writeFileSync(dataFile, JSON.stringify(pets, null, 2));
  res.json({ message: 'Pet deleted', pet: deleted });
});

// PUT (edit) pet
app.put('/pets/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = pets.findIndex(p => p.id === id);
  if (index === -1) return res.status(404).json({ error: 'Pet not found' });

  const { pet_name, species, age } = req.body;
  if (!pet_name || !species || age === undefined)
    return res.status(400).json({ error: 'Missing data' });

  pets[index] = { id, pet_name, species, age };
  fs.writeFileSync(dataFile, JSON.stringify(pets, null, 2));
  res.json({ message: 'Pet updated', pet: pets[index] });
});

app.listen(port, () => console.log(`Server running at http://localhost:${port}`));
