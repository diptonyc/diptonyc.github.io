let pets = [];

document.addEventListener('DOMContentLoaded', () => {
  loadPets();

  document.getElementById('petForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const pet = {
      pet_name: document.getElementById('pet_name').value,
      species: document.getElementById('species').value,
      age: parseInt(document.getElementById('age').value)
    };

    const res = await fetch('/pets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(pet)
    });

    const data = await res.json();
    showToast(`✅ Pet ${data.pet_name} added!`);
    e.target.reset();
    loadPets();
  });

  document.getElementById('editForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('edit_id').value;
    const pet = {
      pet_name: document.getElementById('edit_name').value,
      species: document.getElementById('edit_species').value,
      age: parseInt(document.getElementById('edit_age').value)
    };

    await fetch(`/pets/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(pet)
    });

    showToast(`✅ Pet updated!`);
    bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
    loadPets();
  });
});

async function loadPets() {
  const res = await fetch('/pets');
  pets = await res.json();

  const list = document.getElementById('petList');
  list.innerHTML = '';

  pets.forEach(pet => {
    const li = document.createElement('li');
    li.className = 'list-group-item';
    li.innerHTML = `
      <span><strong>${pet.pet_name}</strong> the ${pet.species} (Age: ${pet.age})</span>
      <div>
        <button class="btn btn-sm btn-warning me-2" onclick="openEditModal(${pet.id})">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deletePet(${pet.id})">Delete</button>
      </div>
    `;
    list.appendChild(li);
  });
}

function openEditModal(id) {
  const pet = pets.find(p => p.id === id);
  document.getElementById('edit_id').value = pet.id;
  document.getElementById('edit_name').value = pet.pet_name;
  document.getElementById('edit_species').value = pet.species;
  document.getElementById('edit_age').value = pet.age;

  const modal = new bootstrap.Modal(document.getElementById('editModal'));
  modal.show();
}

async function deletePet(id) {
  if (!confirm('Are you sure you want to delete this pet?')) return;

  const res = await fetch(`/pets/${id}`, { method: 'DELETE' });
  const result = await res.json();
  showToast(`🗑️ ${result.pet.pet_name} deleted`);
  loadPets();
}

function showToast(message) {
  document.getElementById('toastMessage').textContent = message;
  new bootstrap.Toast(document.getElementById('toast')).show();
}
